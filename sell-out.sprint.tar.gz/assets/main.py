import pygame
import random 
import asyncio
import math
import sys
import platform

HIGHSCORE_KEY = "sellout_highscore"


pygame.init()
# SCHERM INSTELLINGEN
schermhoogte = 640
schermbreedte = 480
scherm = pygame.display.set_mode((schermbreedte, schermhoogte))

#CONSTANTEN
straal_pizza_bodem = 20
straal_pizza_korst = 25
kar_breedte = 70

#KLEUREN
green = (0, 255, 0)
gele_bodem = (255, 252, 1)  
bruine_korst = (180, 130, 15)
rode_pepperoni = (255, 0, 0) 


#GELUIDEN LADEN:
pygame.mixer.init()

vang_snd     = pygame.mixer.Sound("vang.ogg")
bonus_snd    = pygame.mixer.Sound("bonus.ogg")
verlies_snd  = pygame.mixer.Sound("verlies.ogg")
gameover_snd = pygame.mixer.Sound("gameover.ogg")
record_snd   = pygame.mixer.Sound("record.ogg")


#AFBEELDINGEN INLADEN
achtergrond = pygame.transform.scale((pygame.image.load("supermarktthema.png")).convert_alpha(),(schermbreedte,schermhoogte))
pizza_afb = pygame.transform.scale((pygame.image.load("pizza.png")).convert_alpha(),(50,50))
paula = pygame.transform.scale((pygame.image.load("koe.png")).convert_alpha(),(40,40))
remi = pygame.image.load("bonus.png").convert()
remi.set_colorkey((255, 255, 255))          # maak puur wit doorzichtig
remi = pygame.transform.scale(remi, (50, 50))
foodtruck_afb = pygame.transform.scale(pygame.image.load("foodtruck.png").convert_alpha(), (90, 68))

#ANDERE INSTELLINGEN 
pygame.display.set_caption("Sell-Out Sprint")
klok = pygame.time.Clock()
lettertype = pygame.font.SysFont(None, 48)   
lettertype_klein = pygame.font.SysFont(None,32)

# FUNCTIES
def collision(obj, kar_links, kar_rechts):
        return kar_links <= obj["x"] <= kar_rechts and obj["y"] >= 600

def up(obj, hoogte, straal):
    return obj["y"] > hoogte + straal
def wachttijden(obj):
    return obj["wacht"] == 0
def laad_highscore():
    if sys.platform == "emscripten":
        try:
            return int(platform.window.localStorage.getItem(HIGHSCORE_KEY))
        except (TypeError, ValueError):
            return 0
    return 0
def bewaar_highscore(score):
    if sys.platform == "emscripten":
        platform.window.localStorage.setItem(HIGHSCORE_KEY, str(score))

#MAIN LOOP
async def main():
    pizza = {"x":240,
             "y":0,
             "snelheid":2}
    
    powerup = {
        "x":random.randint(20,460),
        "y": -100,
        "snelheid": 4,
        "wacht":random.randint(120,360)}
    bonus = {
        "basis_x": random.randint(80,400), 
        "x":0,
        "y" : - 100,
        "snelheid": 5,
        "wacht": random.randint(120,360)}
    score = 0
    levens = 3
    game_over_timer = 0
    highscore = laad_highscore()
    nieuw_record = False
    running = True

    # GAME STATES DEFINIEREN
    toestand = "intro"


    while running:
        # 1. INPUT — lees wat de speler doet

        #MANIER OM DE LOOP TE STOPPEN
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONUP:
                if toestand == "intro":
                    toestand = "spelen"
                elif toestand == "game over" and game_over_timer == 0:
                    pizza["x"] = 240
                    pizza["y"] = 0
                    pizza["snelheid"] = 2
                    score = 0
                    levens = 3
                    toestand = "spelen"
                    nieuw_record = False
        
            
        
        if toestand == "spelen":

            # POSITIE VAN DE MUIS VAN DE SPELER UITLEZEN
            muis_x, muis_y = pygame.mouse.get_pos()

            # OBJECTEN LATEN VALLEN
            pizza["y"]+= pizza["snelheid"]
            if not wachttijden(powerup):
                powerup["wacht"] -= 1
            else:
                powerup["y"] += powerup["snelheid"]
            
            if not wachttijden(bonus):
                bonus["wacht"] -= 1
            else:
                bonus["y"] += bonus["snelheid"]
                bonus["x"] = bonus["basis_x"] + 170 * math.sin(bonus["y"] * 0.01)

            # OBJECTEN RESETTEN
            if up(powerup,schermhoogte,straal_pizza_bodem):
                powerup["y"] = -100
                powerup["x"] = random.randint(20,460)
                powerup["wacht"] = random.randint(120,360)
            if up(pizza,schermhoogte,straal_pizza_bodem):
                verlies_snd.play()
                pizza["y"]= 0
                pizza["x"] = random.randint(20,460)
                levens -= 1
            if up(bonus, schermhoogte,straal_pizza_bodem):
                bonus["y"], bonus["basis_x"] = -100, random.randint(80, 400)
                bonus["wacht"] = random.randint(120,360)

            # UITEINDEN BEPALEN VAN DE KAR
            kar_links = muis_x - kar_breedte / 2
            kar_rechts = muis_x + kar_breedte / 2

            # OBJECTEN VANGEN DEFINIEREN
            if collision(pizza,kar_links,kar_rechts):
                vang_snd.play()
                score += 1
                pizza["y"]= 0
                pizza["x"] = random.randint(20,460)
                pizza["snelheid"] += 0.5
            if collision(powerup,kar_links,kar_rechts):
                vang_snd.play()
                if pizza["snelheid"] >= 3:
                    pizza["snelheid"] -= 1
                powerup["y"] = -100
                powerup["x"] = random.randint(20,460)
                powerup["wacht"] = random.randint(120,500)
            if collision(bonus, kar_links, kar_rechts):
                bonus_snd.play()
                score += 3
                bonus["y"] = -100
                bonus["basis_x"] = random.randint(80, 400)
                bonus["wacht"] = random.randint(120, 360)
                bonus["snelheid"] += 1
                pizza["snelheid"] += 0.5
            #GAME OVER DEFINIEREN
            if levens == 0:
                toestand = "game over"
                game_over_timer = 60
                nieuw_record = score > highscore
                if nieuw_record:
                    record_snd.play()
                    highscore = score
                    bewaar_highscore(highscore)
                else:
                    gameover_snd.play()
        elif toestand == "game over":
            if game_over_timer > 0:
                game_over_timer -= 1
        # 3. TEKENEN
        scherm.fill((22, 33, 62))   
        scherm.blit(achtergrond)

        if toestand == "spelen":
            # TEKEN DE ELEMENTEN
            scherm.blit(pizza_afb, (pizza["x"] - 50 / 2, pizza["y"]- 50 / 2))
            scherm.blit(paula,(powerup["x"] - 40 / 2, powerup["y"] - 40 / 2))
            scherm.blit(remi, (bonus["x"] - 50 /2, bonus["y"] - 50/2))
            scherm.blit(foodtruck_afb, (muis_x - 90 / 2, 580))
        

            #TEKEN DE TEKSTEN
            tekst_score = lettertype.render(f"Score: {score}", True, (255, 255, 255))
            tekst_levens = lettertype.render(f"Levens : {levens}", True, (255,255,255))
            scherm.blit(tekst_score, (10, 10))
            scherm.blit(tekst_levens,(310,10))
        elif toestand == "game over":
            tekst_gameover = lettertype.render((f"GAME OVER"), True,rode_pepperoni)
            tekst_eindscore = lettertype.render(f"Score: {score}", True, rode_pepperoni)
            tekst_newgame = lettertype_klein.render(f"Nog een rondje? \n(druk op een toets)",True,rode_pepperoni)
            hoogste_score = lettertype_klein.render(f"Current highscore: {highscore}",True,rode_pepperoni)
            if nieuw_record:
                record = lettertype_klein.render(f"NIEUW RECORD, schrijf het op!",True,rode_pepperoni)
                scherm.blit(record, ((schermbreedte - record.get_width())/2, 480))
                scherm.blit(remi, ((schermbreedte - remi.get_width())/2,510))
            scherm.blit(tekst_gameover, (140, 240))
            scherm.blit(tekst_eindscore, (140, 280))
            scherm.blit(tekst_newgame,(140, 340))
            scherm.blit(hoogste_score, ((schermbreedte - hoogste_score.get_width())/2, 600))
        

        elif toestand == "intro":
            titel = lettertype.render(f"SELL-OUT SPRINT",True, gele_bodem)
            scherm.blit(titel, ((schermbreedte - titel.get_width())/2, 70))

            doel = lettertype_klein.render("Vang de pizza's, mis er geen!", True, (255,255,255))
            scherm.blit(doel, ((schermbreedte - doel.get_width())/2, 140))

            legenda = [
            (pizza_afb, "= +1 punt"),
            (paula,     "= trager"),
            (remi,      "= +3 (sneller!)")]

            y = 210
            for sprite, uitleg in legenda:
                scherm.blit(sprite, (110, y))
                regel = lettertype_klein.render(uitleg, True, (255,255,255))
                scherm.blit(regel, (180, y + 12))
                y += 60

            verlies = lettertype_klein.render("Mis een pizza = -1 leven", True, rode_pepperoni)
            scherm.blit(verlies, ((schermbreedte - verlies.get_width())/2, 410))

            start = lettertype_klein.render("Druk op een toets om te starten", True, bruine_korst)
            scherm.blit(start, ((schermbreedte - start.get_width())/2, 500))

            current_high = lettertype_klein.render(f"Highscore: {highscore}",True,rode_pepperoni)
            scherm.blit(current_high,((schermbreedte - current_high.get_width())/2, 600))

        pygame.display.flip()        
        klok.tick(60)                
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())