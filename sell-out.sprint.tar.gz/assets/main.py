import pygame
import random 
import asyncio


pygame.init()
schermhoogte = 640
schermbreedte = 480
straal_pizza = 20
scherm = pygame.display.set_mode((schermbreedte, schermhoogte))
pygame.display.set_caption("Sell-Out Sprint")
klok = pygame.time.Clock()
green = (0, 255, 0)
kar_breedte = 70
lettertype = pygame.font.SysFont(None, 48)   # standaard font, grootte 48

async def main():
    Pizza_x = 240
    Pizza_y = 0
    Pizza_snelheid = 4
    score = 0
    levens = 3
    running = True
    while running:
        # 1. INPUT — lees wat de speler doet
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # 2. UPDATE — (nog niks)
        muis_x, muis_y = pygame.mouse.get_pos()
        Pizza_y += Pizza_snelheid
        if Pizza_y > schermhoogte + straal_pizza:
            Pizza_y = 0
            Pizza_x = random.randint(20,460)
            levens -= 1
        kar_links = muis_x - kar_breedte / 2
        kar_rechts = muis_x + kar_breedte / 2

        if kar_links <= Pizza_x <= kar_rechts and Pizza_y >= 600:
            score += 1
            Pizza_y = 0
            Pizza_x = random.randint(20,460)
            Pizza_snelheid += 0.5
        if levens == 0:
            running = False    
        # 3. TEKENEN
        scherm.fill((22, 33, 62))   # achtergrond opnieuw vullen
        pygame.draw.circle(scherm,(240,200,80), (Pizza_x,Pizza_y),straal_pizza)
        tekst_score = lettertype.render(f"Score: {score}", True, (255, 255, 255))
        tekst_levens = lettertype.render(f"Levens : {levens}", True, (255,255,255))
        scherm.blit(tekst_score, (10, 10))
        scherm.blit(tekst_levens,(310,10))

        # 👇 jouw code komt hier
        pygame.draw.rect(scherm, green, (muis_x - kar_breedte /2, 600, kar_breedte, 20),0)
        pygame.display.flip()        # toon het nieuwe frame
        klok.tick(60)                # maximaal 60 frames per seconde
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())