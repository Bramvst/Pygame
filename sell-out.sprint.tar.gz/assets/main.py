import pygame
import random 
import asyncio


pygame.init()
# SCHERM INSTELLINGEN
schermhoogte = 640
schermbreedte = 480
scherm = pygame.display.set_mode((schermbreedte, schermhoogte))

#CONSTANTEN
straal_pizza_bodem = 20
straal_pizza_korst = 25
kar_breedte = 70
green = (0, 255, 0)
gele_bodem = (255, 252, 1)  
bruine_korst = (180, 130, 15)
rode_pepperoni = (255, 0, 0) 

#ANDERE INSTELLINGEN 
pygame.display.set_caption("Sell-Out Sprint")
klok = pygame.time.Clock()
lettertype = pygame.font.SysFont(None, 48)   # standaard font, grootte 48
lettertype_klein = pygame.font.SysFont(None,32)

#MAIN LOOP
async def main():
    pizza_x_bodem = 240
    pizza_y_bodem = 0
    Pizza_snelheid = 4
    score = 0
    levens = 3
    running = True

    # GAME STATES DEFINIEREN
    toestand = "intro"


    while running:
        # 1. INPUT — lees wat de speler doet

        #MANIER OM DE LOOP TE STOPPEN
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if toestand == "intro":
                    toestand = "spelen"
                elif toestand == "game over":
                    pizza_x_bodem = 240
                    pizza_y_bodem = 0
                    Pizza_snelheid = 4
                    score = 0
                    levens = 3
                    toestand = "spelen"
        
            
        
        if toestand == "spelen":
            # 2. UPDATE
            # POSITIE VAN DE MUIS VAN DE SPELER UITLEZEN
            muis_x, muis_y = pygame.mouse.get_pos()
            #PIZZA LATEN VALLEN
            pizza_y_bodem += Pizza_snelheid
            # PIZZA RANDOM OPNIEUW TONEN ALS GEMIST IS 
            if pizza_y_bodem > schermhoogte + straal_pizza_bodem:
                pizza_y_bodem = 0
                pizza_x_bodem = random.randint(20,460)
                levens -= 1
            # UITEINDEN BEPALEN VAN DE KAR
            kar_links = muis_x - kar_breedte / 2
            kar_rechts = muis_x + kar_breedte / 2
            # PIZZA VANGEN DEFINIEREN
            if kar_links <= pizza_x_bodem <= kar_rechts and pizza_y_bodem >= 600:
                score += 1
                pizza_y_bodem = 0
                pizza_x_bodem = random.randint(20,460)
                Pizza_snelheid += 0.5
            #GAME OVER DEFINIEREN
            if levens == 0:
                toestand = "game over"  
        # 3. TEKENEN
        scherm.fill((22, 33, 62))   # achtergrond opnieuw vullen
        if toestand == "spelen":

            
            # TEKEN DE PIZZA
            pygame.draw.circle(scherm,gele_bodem, (pizza_x_bodem,pizza_y_bodem),straal_pizza_bodem)
            pygame.draw.circle(scherm,bruine_korst, (pizza_x_bodem,pizza_y_bodem),straal_pizza_korst,5)
            # STIPPEN OP DE PIZZA
            pygame.draw.circle(scherm, rode_pepperoni,(pizza_x_bodem+1,pizza_y_bodem+3),2)
            pygame.draw.circle(scherm, rode_pepperoni,(pizza_x_bodem+10,pizza_y_bodem+1),2)
            pygame.draw.circle(scherm,  rode_pepperoni,(pizza_x_bodem-10,pizza_y_bodem+8),2)
            pygame.draw.circle(scherm,  rode_pepperoni,(pizza_x_bodem-10,pizza_y_bodem-11),2)
            pygame.draw.circle(scherm,  rode_pepperoni,(pizza_x_bodem,pizza_y_bodem-11),2)
            pygame.draw.circle(scherm,  rode_pepperoni,(pizza_x_bodem,pizza_y_bodem+16),2)
            pygame.draw.rect(scherm, green, (muis_x - kar_breedte /2, 600, kar_breedte, 20),0)
            #TEKEN DE TEKSTEN
            tekst_score = lettertype.render(f"Score: {score}", True, (255, 255, 255))
            tekst_levens = lettertype.render(f"Levens : {levens}", True, (255,255,255))
            scherm.blit(tekst_score, (10, 10))
            scherm.blit(tekst_levens,(310,10))
        elif toestand == "game over":
            tekst_gameover = lettertype.render((f"GAME OVER"), True,rode_pepperoni)
            tekst_eindscore = lettertype.render(f"Eindscore: {score}", True, rode_pepperoni)
            tekst_newgame = lettertype_klein.render(f"Nog een rondje? \n(druk op een toets)",True,rode_pepperoni)
            # 640, 480
            scherm.blit(tekst_gameover, (140, 240))
            scherm.blit(tekst_eindscore, (140, 280))
            scherm.blit(tekst_newgame,(140, 340))

        elif toestand == "intro":
            tekst_start = lettertype_klein.render(f"Wil jij onze extra sellout voor \n 2026 voorzien?",True,gele_bodem)
            tekst_hoe_start = lettertype_klein.render(f"Druk op een toets om te starten...",True, bruine_korst)
            x = (schermbreedte - tekst_start.get_width())/2
            y = (schermbreedte - tekst_hoe_start.get_width())/2
            scherm.blit(tekst_start,(x,240))
            scherm.blit(tekst_hoe_start,(y,330))

        pygame.display.flip()        # toon het nieuwe frame
        klok.tick(60)                # maximaal 60 frames per seconde
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())