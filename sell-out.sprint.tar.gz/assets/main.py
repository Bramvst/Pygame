import pygame
import random 
import asyncio
import math


pygame.init()
# SCHERM INSTELLINGEN
schermhoogte = 640
schermbreedte = 480
scherm = pygame.display.set_mode((schermbreedte, schermhoogte))

#CONSTANTEN
straal_pizza_bodem = 20
straal_pizza_korst = 25
kar_breedte = 70

#KLEUREN
green = (0, 255, 0)
gele_bodem = (255, 252, 1)  
bruine_korst = (180, 130, 15)
rode_pepperoni = (255, 0, 0) 



#AFBEELDINGEN INLADEN
achtergrond = pygame.transform.scale((pygame.image.load("supermarktthema.png")).convert_alpha(),(schermbreedte,schermhoogte))
pizza_afb = pygame.transform.scale((pygame.image.load("pizza.png")).convert_alpha(),(50,50))
paula = pygame.transform.scale((pygame.image.load("koe.png")).convert_alpha(),(40,40))
remi = pygame.image.load("bonus.png").convert()
remi.set_colorkey((255, 255, 255))          # maak puur wit doorzichtig
remi = pygame.transform.scale(remi, (50, 50))

#ANDERE INSTELLINGEN 
pygame.display.set_caption("Sell-Out Sprint")
klok = pygame.time.Clock()
lettertype = pygame.font.SysFont(None, 48)   
lettertype_klein = pygame.font.SysFont(None,32)

# FUNCTIES
def collision(obj, kar_links, kar_rechts):
        return kar_links <= obj["x"] <= kar_rechts and obj["y"] >= 600

def up(obj, hoogte, straal):
    return obj["y"] > hoogte + straal

#MAIN LOOP
async def main():
    pizza = {"x":240,
             "y":0,
             "snelheid":2}
    
    powerup = {
        "x":random.randint(20,460),
        "y": -100,
        "snelheid": 4}
    bonus = {
        "basis_x": random.randint(80,400), 
        "x":0,
        "y" : - 100,
        "snelheid": 5,
        "wacht": random.randint(120,360)}
    score = 0
    levens = 3
    running = True

    # GAME STATES DEFINIEREN
    toestand = "intro"


    while running:
        # 1. INPUT — lees wat de speler doet

        #MANIER OM DE LOOP TE STOPPEN
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONUP:
                if toestand == "intro":
                    toestand = "spelen"
                elif toestand == "game over":
                    pizza["x"] = 240
                    pizza["y"] = 0
                    pizza["snelheid"] = 2
                    score = 0
                    levens = 3
                    toestand = "spelen"
        
            
        
        if toestand == "spelen":
            # POSITIE VAN DE MUIS VAN DE SPELER UITLEZEN
            muis_x, muis_y = pygame.mouse.get_pos()

            # OBJECTEN LATEN VALLEN
            powerup["y"] += powerup["snelheid"]
            pizza["y"]+= pizza["snelheid"]
            if bonus["wacht"] > 0:
                bonus["wacht"] -= 1
            else:
                bonus["y"] += bonus["snelheid"]
                bonus["x"] = bonus["basis_x"] + 160 * math.sin(bonus["y"] * 0.03)

            # OBJECTEN RESETTEN
            if up(powerup,schermhoogte,straal_pizza_bodem):
                powerup["y"] = -100
                powerup["x"] = random.randint(20,460)
            if up(pizza,schermhoogte,straal_pizza_bodem):
                pizza["y"]= 0
                pizza["x"] = random.randint(20,460)
                levens -= 1
            if up(bonus, schermhoogte,straal_pizza_bodem):
                bonus["y"], bonus["basis_x"] = -100, random.randint(80, 400)
                bonus["wacht"] = random.randint(120,360)

            # UITEINDEN BEPALEN VAN DE KAR
            kar_links = muis_x - kar_breedte / 2
            kar_rechts = muis_x + kar_breedte / 2

            # OBJECTEN VANGEN DEFINIEREN
            if collision(pizza,kar_links,kar_rechts):
                score += 1
                pizza["y"]= 0
                pizza["x"] = random.randint(20,460)
                pizza["snelheid"] += 0.5
            if collision(powerup,kar_links,kar_rechts):
                if pizza["snelheid"] >= 3:
                    pizza["snelheid"] -= 0.5
                powerup["y"] = -100
            if collision(bonus, kar_links, kar_rechts):
                score += 3
                bonus["y"] = -100
                bonus["basis_x"] = random.randint(80, 400)
                bonus["wacht"] = random.randint(120, 360)
                bonus["snelheid"] += 1
                pizza["snelheid"] += 0.5
            #GAME OVER DEFINIEREN
            if levens == 0:
                toestand = "game over"  

        # 3. TEKENEN
        scherm.fill((22, 33, 62))   
        scherm.blit(achtergrond)

        if toestand == "spelen":
            # TEKEN DE PIZZA
            scherm.blit(pizza_afb, (pizza["x"] - 50 / 2, pizza["y"]- 50 / 2))
            scherm.blit(paula,(powerup["x"] - 40 / 2, powerup["y"] - 40 / 2))
            scherm.blit(remi, (bonus["x"] - 50 /2, bonus["y"] - 50/2))

            # KAR tekenen
            pygame.draw.rect(scherm, green, (muis_x - kar_breedte /2, 600, kar_breedte, 20),0)
        

            #TEKEN DE TEKSTEN
            tekst_score = lettertype.render(f"Score: {score}", True, (255, 255, 255))
            tekst_levens = lettertype.render(f"Levens : {levens}", True, (255,255,255))
            scherm.blit(tekst_score, (10, 10))
            scherm.blit(tekst_levens,(310,10))
        elif toestand == "game over":
            tekst_gameover = lettertype.render((f"GAME OVER"), True,rode_pepperoni)
            tekst_eindscore = lettertype.render(f"Eindscore: {score}", True, rode_pepperoni)
            tekst_newgame = lettertype_klein.render(f"Nog een rondje? \n(druk op een toets)",True,rode_pepperoni)
            scherm.blit(tekst_gameover, (140, 240))
            scherm.blit(tekst_eindscore, (140, 280))
            scherm.blit(tekst_newgame,(140, 340))

        elif toestand == "intro":
            titel = lettertype.render(f"SELL-OUT SPRINT",True, gele_bodem)
            scherm.blit(titel, ((schermbreedte - titel.get_width())/2, 70))

            doel = lettertype_klein.render("Vang de pizza's, mis er geen!", True, (255,255,255))
            scherm.blit(doel, ((schermbreedte - doel.get_width())/2, 140))

            legenda = [
            (pizza_afb, "= +1 punt"),
            (paula,     "= trager"),
            (remi,      "= +3 (sneller!)")]

            y = 210
            for sprite, uitleg in legenda:
                scherm.blit(sprite, (110, y))
                regel = lettertype_klein.render(uitleg, True, (255,255,255))
                scherm.blit(regel, (180, y + 12))
                y += 60

            verlies = lettertype_klein.render("Mis een pizza = -1 leven", True, rode_pepperoni)
            scherm.blit(verlies, ((schermbreedte - verlies.get_width())/2, 410))

            start = lettertype_klein.render("Druk op een toets om te starten", True, bruine_korst)
            scherm.blit(start, ((schermbreedte - start.get_width())/2, 500))
        pygame.display.flip()        
        klok.tick(60)                
        await asyncio.sleep(0)

    pygame.quit()
asyncio.run(main())